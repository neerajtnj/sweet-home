package com.micro.booking.hotel.exception;

public class BookingException extends RuntimeException{

    private String errorMgs;

    public BookingException(String errorMgs)
    {
        this.errorMgs=errorMgs;
    }

    public String getErrorMgs() {
        return errorMgs;
    }

}
