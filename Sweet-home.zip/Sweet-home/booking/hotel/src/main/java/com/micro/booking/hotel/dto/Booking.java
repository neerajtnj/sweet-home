package com.micro.booking.hotel.dto;

import com.fasterxml.jackson.annotation.JacksonAnnotation;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Booking {

    private Integer id;
    private String aadharNumber;

    @NotNull(message = "From Date should not be null")
    private LocalDateTime fromDate;
    @NotNull(message = "To Date should not be null")
    private LocalDateTime toDate;
    @NotNull
    private Integer numOfRooms;
    private BigDecimal roomPrice;
    private LocalDateTime bookedOn;
    private String roomNumbers;
    private Integer transactionId;
}
