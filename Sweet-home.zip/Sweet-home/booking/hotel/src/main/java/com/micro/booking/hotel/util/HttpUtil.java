package com.micro.booking.hotel.util;

import com.micro.booking.hotel.exception.BookingException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.net.URISyntaxException;

@Service
@Slf4j
public class HttpUtil {

    @Autowired
    private RestTemplate restTemplate;

    public String postResult(String url, HttpHeaders headers,Object input) throws URISyntaxException {

        HttpEntity<Object> httpEntity= new HttpEntity<Object>(input,headers);

        URI uri = new URI(url);
        try {
            log.info("Inside rest");
            ResponseEntity<String> resp = restTemplate.exchange(uri, HttpMethod.POST, httpEntity, String.class);
            log.info("resp");
            if(resp.getBody()!=null)
            {
                return resp.getBody();
            }
        }
        catch (RestClientException ex)
        {
            throw new BookingException("Exception Occured");
        }
        return  null;
    }
}
