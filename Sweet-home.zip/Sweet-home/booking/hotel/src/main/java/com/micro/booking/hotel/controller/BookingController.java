package com.micro.booking.hotel.controller;

import com.micro.booking.hotel.dto.Booking;
import com.micro.booking.hotel.dto.PaymentInfo;
import com.micro.booking.hotel.service.BookingService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping
@Slf4j
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @PostMapping("/booking")
    public ResponseEntity<Booking> booking(@Valid @RequestBody Booking booking)
    {
        Booking bookingInfo = bookingService.saveBooking(booking);
        return ResponseEntity.status(HttpStatus.CREATED).body(bookingInfo);
    }

    @PostMapping("/booking/{bookingId}/transaction")
    public ResponseEntity<Booking> bookingTransaction(@Valid @RequestBody PaymentInfo paymentInfo
            , @PathVariable Integer bookingId)
    {
        log.info("Enter in transaction");
        paymentInfo.setBookingId(String.valueOf(bookingId));
        Booking booking = bookingService.bookingPayment(paymentInfo);
        return ResponseEntity.status(HttpStatus.CREATED).body(booking);
    }
}
