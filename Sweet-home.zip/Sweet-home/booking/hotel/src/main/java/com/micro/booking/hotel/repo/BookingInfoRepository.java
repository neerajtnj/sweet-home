package com.micro.booking.hotel.repo;

import com.micro.booking.hotel.entity.BookingInfoEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BookingInfoRepository extends JpaRepository<BookingInfoEntity,Integer> {
}
