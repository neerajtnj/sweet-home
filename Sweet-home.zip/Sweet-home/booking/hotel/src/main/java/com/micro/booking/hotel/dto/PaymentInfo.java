package com.micro.booking.hotel.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Pattern;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PaymentInfo {

    private String paymentMode;
    private String upiId;
    private String cardNumber;
    private String bookingId;
}
