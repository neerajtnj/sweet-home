package com.micro.booking.hotel.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Generated;
import org.springframework.web.bind.annotation.GetMapping;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity(name = "BOOKING")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BookingInfoEntity {

    @Id
    @GeneratedValue
    @Column(name="booking_id")
    private Integer id;

    private String aadharNumber;

    private LocalDateTime fromDate;

    private LocalDateTime toDate;

    private LocalDateTime bookedOn;

    private Integer transactionId;
    private Integer numOfRooms;
    private BigDecimal roomPrice;
    private String roomNumbers;


}
