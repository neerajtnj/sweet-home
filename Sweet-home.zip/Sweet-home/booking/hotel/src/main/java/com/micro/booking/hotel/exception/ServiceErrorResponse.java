package com.micro.booking.hotel.exception;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
public class ServiceErrorResponse {

    private String message;
    private String statusCode;
}
