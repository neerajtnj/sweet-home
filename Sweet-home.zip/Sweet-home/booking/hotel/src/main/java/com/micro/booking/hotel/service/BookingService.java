package com.micro.booking.hotel.service;

import com.micro.booking.hotel.dto.Booking;
import com.micro.booking.hotel.dto.PaymentInfo;
import com.micro.booking.hotel.entity.BookingInfoEntity;
import com.micro.booking.hotel.exception.BookingException;
import com.micro.booking.hotel.repo.BookingInfoRepository;
import com.micro.booking.hotel.util.HttpUtil;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Optional;
import java.util.Random;

import static java.time.temporal.ChronoUnit.DAYS;

@Service
@Slf4j
public class BookingService {

    @Autowired
    private BookingInfoRepository bookingInfoRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private HttpUtil httpUtil;

    @Value("${payment.service.url}")
    private String paymentUrl;

    @Transactional
    public Booking saveBooking(Booking booking)
    {


        log.info("Enter in saving method");
        BookingInfoEntity bookingInfoEntity = modelMapper.map(booking, BookingInfoEntity.class);
        bookingInfoEntity.setTransactionId(0);
        bookingInfoEntity.setBookedOn(LocalDateTime.now());
        bookingInfoEntity.setRoomPrice(getPrice(booking.getNumOfRooms(), booking.getFromDate(), booking.getToDate()));
        bookingInfoEntity.setRoomNumbers(getRandomNumbers(booking.getNumOfRooms()));
        BookingInfoEntity entity = bookingInfoRepository.save(bookingInfoEntity);
        log.info("BookingId {}",entity.getId());
        Booking bookingInfo = Booking.builder().id(entity.getId()).bookedOn(LocalDateTime.now())
                .aadharNumber(entity.getAadharNumber()).fromDate(booking.getFromDate())
                .roomNumbers(entity.getRoomNumbers())
                .roomPrice(entity.getRoomPrice())
                .transactionId(entity.getTransactionId())
                .toDate(entity.getToDate())
                .numOfRooms(entity.getNumOfRooms())
                .build();
        return bookingInfo;
    }

    private  String getRandomNumbers(int count){
        Random rand = new Random();
        int upperBound = 100;
        StringBuilder sb= new StringBuilder();

        for (int i=0; i<count; i++){
            sb.append(String.valueOf(rand.nextInt(upperBound)));
            sb.append(",");
        }

        return sb.toString().substring(0,sb.length()-1);
    }

    public Booking transaction(PaymentInfo info,Integer bookingId)
    {

        return null;
    }

    private BigDecimal getPrice(int noOfRooms, LocalDateTime fromDate,LocalDateTime toDate)
    {
        long noOfDays = DAYS.between(fromDate, toDate);
        BigDecimal price= BigDecimal.valueOf(1000*noOfDays*noOfRooms);
        return price;
    }

    @Transactional
    public Booking bookingPayment(PaymentInfo paymentInfo)
    {

        if(!(paymentInfo.getPaymentMode().equals("UPI") || paymentInfo.getPaymentMode().equals("CARD") ))
        {
            throw new BookingException("Invalid mode of payment");
        }
        try {

            Optional<BookingInfoEntity> bookingInfoEntity = bookingInfoRepository.findById(Integer.valueOf(paymentInfo.getBookingId()));
            log.info(bookingInfoEntity.toString());
            if (!bookingInfoEntity.isPresent()) {
                throw new BookingException("Invalid Booking Id");
            }

            HttpHeaders headers = new HttpHeaders();
            headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

            String resp = httpUtil.postResult(paymentUrl, headers, paymentInfo);
            log.info(resp);
            if (resp != null) {
                log.info("Response from payment service");
                bookingInfoEntity.get().setTransactionId(Integer.valueOf(resp));
                BookingInfoEntity entity = bookingInfoRepository.save(bookingInfoEntity.get());
                Booking responseDto = modelMapper.map(entity, Booking.class);
                return responseDto;
            } else {
                throw new BookingException("Payment service down");
            }
        }
        catch (Exception ex)
        {
            throw new BookingException("Invalid Booking ID");
        }

    }
}
