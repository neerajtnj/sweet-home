package com.micro.discoverysever;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscoveryseverApplicationTests {

	@Test
	void contextLoads() {
	}

}
