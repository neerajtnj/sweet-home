package com.micro.booking.payment.controller;

import com.micro.booking.payment.dto.TransactionDto;
import com.micro.booking.payment.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping
public class PaymentController {

    @Autowired
    private PaymentService service;

    @PostMapping("/payment")
    public ResponseEntity<Integer> payment(@RequestBody TransactionDto transactionDto)
    {

        Integer resp = service.savePaymentDetails(transactionDto);
        return ResponseEntity.ok(resp);
    }

    @GetMapping("/transaction/{transactionId}")
    public ResponseEntity<TransactionDto> payment(@PathVariable Integer transactionId)
    {

        TransactionDto resp = service.getPaymentDetails(transactionId);
        return ResponseEntity.ok(resp);
    }
}
