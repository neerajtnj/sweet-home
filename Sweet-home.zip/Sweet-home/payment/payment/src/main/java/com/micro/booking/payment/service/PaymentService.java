package com.micro.booking.payment.service;

import com.micro.booking.payment.dto.TransactionDto;
import com.micro.booking.payment.entity.Transaction;
import com.micro.booking.payment.repo.TransactionRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class PaymentService {

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private TransactionRepository repository;

    @Transactional
    public Integer savePaymentDetails(TransactionDto transactionDto)
    {
        Transaction resp = modelMapper.map(transactionDto, Transaction.class);
        Transaction respEntity = repository.save(resp);
        return respEntity.getTransactionId();
    }

    public TransactionDto getPaymentDetails(Integer id)
    {
        Optional<Transaction> entity = repository.findById(id);
        TransactionDto dto = new TransactionDto();
        if(entity.isPresent())
        {
            Transaction transaction = entity.get();
            dto= modelMapper.map(transaction,TransactionDto.class);
        }
        return dto;
    }

}
